// Name: Jaquan Rhodes
// Date: May 30, 2024
// Assignment: Course Project

using System;

namespace TodoListApp
{
    // Class: TodoItem
    public class TodoItem
    {
        // Properties
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public string Status { get; set; }

        // Constructor
        public TodoItem(string title, string description, DateTime dueDate, string status)
        {
            Title = title;
            Description = description;
            DueDate = dueDate;
            Status = status;
        }

        // Methods
        public override string ToString()
        {
            return $"Title: {Title}\nDescription: {Description}\nDue Date: {DueDate.ToShortDateString()}\nStatus: {Status}";
        }

        public void UpdateStatus(string newStatus)
        {
            Status = newStatus;
        }
    }
}
