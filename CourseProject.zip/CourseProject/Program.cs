﻿// Name: Jaquan Rhodes
// Date: May 30, 2024
// Assignment: Course Project

using System;
using System.Collections.Generic;

namespace TodoListApp
{
    // Class: Program
    class Program
    {
        static void Main(string[] args)
        {
            TodoList todoList = new TodoList();

            while (true)
            {
                Console.WriteLine("Simple To-Do List Manager");
                Console.WriteLine("1. Add To-Do Item");
                Console.WriteLine("2. Remove To-Do Item");
                Console.WriteLine("3. Update To-Do Item");
                Console.WriteLine("4. List All To-Do Items");
                Console.WriteLine("5. Exit");
                Console.Write("Select an option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddTodoItem(todoList);
                        break;
                    case "2":
                        RemoveTodoItem(todoList);
                        break;
                    case "3":
                        UpdateTodoItem(todoList);
                        break;
                    case "4":
                        todoList.ListItems();
                        break;
                    case "5":
                        return;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }

        static void AddTodoItem(TodoList todoList)
        {
            Console.Write("Enter title: ");
            string title = Console.ReadLine();
            Console.Write("Enter description: ");
            string description = Console.ReadLine();
            Console.Write("Enter due date (yyyy-mm-dd): ");
            DateTime dueDate;
            while (!DateTime.TryParse(Console.ReadLine(), out dueDate))
            {
                Console.Write("Invalid date format. Please enter due date (yyyy-mm-dd): ");
            }
            Console.Write("Enter status (pending, in progress, completed): ");
            string status = Console.ReadLine();

            TodoItem item = new TodoItem(title, description, dueDate, status);
            todoList.AddItem(item);

            Console.WriteLine("To-Do item added successfully.");
        }

        static void RemoveTodoItem(TodoList todoList)
        {
            Console.Write("Enter title of the item to remove: ");
            string title = Console.ReadLine();
            todoList.RemoveItem(title);
        }

        static void UpdateTodoItem(TodoList todoList)
        {
            Console.Write("Enter title of the item to update: ");
            string title = Console.ReadLine();
            TodoItem item = todoList.GetItem(title);
            if (item != null)
            {
                Console.Write("Enter new title: ");
                item.Title = Console.ReadLine();
                Console.Write("Enter new description: ");
                item.Description = Console.ReadLine();
                Console.Write("Enter new due date (yyyy-mm-dd): ");
                DateTime dueDate;
                while (!DateTime.TryParse(Console.ReadLine(), out dueDate))
                {
                    Console.Write("Invalid date format. Please enter due date (yyyy-mm-dd): ");
                }
                item.DueDate = dueDate;
                Console.Write("Enter new status (pending, in progress, completed): ");
                item.Status = Console.ReadLine();

                todoList.UpdateItem(title, item);

                Console.WriteLine("To-Do item updated successfully.");
            }
            else
            {
                Console.WriteLine("Item not found.");
            }
        }
    }
}

