// Name: Jaquan Rhodes
// Date: May 30, 2024
// Assignment: Course Project

using System;
using System.Collections.Generic;

namespace TodoListApp
{
    // Class: TodoList
    public class TodoList
    {
        // Properties
        private List<TodoItem> Items { get; set; }

        // Constructor
        public TodoList()
        {
            Items = new List<TodoItem>();
        }

        // Methods
        public void AddItem(TodoItem item)
        {
            Items.Add(item);
        }

        public void RemoveItem(string title)
        {
            var item = GetItem(title);
            if (item != null)
            {
                Items.Remove(item);
            }
            else
            {
                Console.WriteLine("Item not found.");
            }
        }

        public void UpdateItem(string title, TodoItem updatedItem)
        {
            var item = GetItem(title);
            if (item != null)
            {
                item.Title = updatedItem.Title;
                item.Description = updatedItem.Description;
                item.DueDate = updatedItem.DueDate;
                item.Status = updatedItem.Status;
            }
            else
            {
                Console.WriteLine("Item not found.");
            }
        }

        public TodoItem GetItem(string title)
        {
            return Items.Find(item => item.Title.Equals(title, StringComparison.OrdinalIgnoreCase));
        }

        public void ListItems()
        {
            if (Items.Count == 0)
            {
                Console.WriteLine("No items to display.");
            }
            else
            {
                foreach (var item in Items)
                {
                    Console.WriteLine(item.ToString());
                    Console.WriteLine("--------------------------------------------------");
                }
            }
        }
    }
}
